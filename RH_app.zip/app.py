from depthai_sdk import OakCamera
from depthai_sdk.classes import DetectionPacket
from robothub import BaseApplication, LiveView
import cv2
import numpy as np
import time
class BusinessLogic:
    live_view = None

    def process_packets(self, packet: DetectionPacket):
        # Create a VideoCapture object and read from input file
        # If the input is the camera, pass 0 instead of the video file name
        cap = cv2.VideoCapture('test.mp4')
        # Check if camera opened successfully
        if (cap.isOpened()== False): 
            print("Error opening video stream or file")
        
        # Read until video is completed
        while(cap.isOpened()):
            # Capture frame-by-frame
            ret, frame = cap.read()
            if ret == True:
                # Convert to grayscale. 
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) 
                
                # Blur using 3 * 3 kernel. 
                gray_blurred = cv2.blur(gray, (3, 3)) 
                
                # Apply Hough transform on the blurred image. 
                detected_circles = cv2.HoughCircles(gray_blurred,  
                                cv2.HOUGH_GRADIENT, 1, 90, param1 = 100, 
                            param2 = 60, minRadius = 50, maxRadius = 120) 
                
                # Draw circles that are detected.
                if detected_circles is not None: 
                
                    # Convert the circle parameters a, b and r to integers. 
                    detected_circles = np.uint16(np.around(detected_circles)) 
                    cups = 0
                    for pt in detected_circles[0, :]: 
                        a, b, r = pt[0], pt[1], pt[2] 
                
                        # Draw the circumference of the circle. 
                        #cv2.circle(frame, (a, b), r, (0, 255, 0), 2) 
                
                        # Draw a small circle (of radius 1) to show the center. 
                        #cv2.circle(frame, (a, b), 1, (0, 0, 255), 3) 
                        cups += 1
                    #frame = cv2.putText(frame, str(cups), (50, 50), cv2.FONT_HERSHEY_SIMPLEX ,  
                    #2, (255,0,0), 2, cv2.LINE_AA) 
                time.sleep(0.1)
                print('Curentli there are {} cups'.format(cups))

            # Break the loop
            else: 
                break
            
        cap.release()
        print('End of mugs detection')


class Application(BaseApplication):
    business_logic = BusinessLogic()

    def setup_pipeline(self, oak: OakCamera):
        """
        Define your data pipeline. Can be called multiple times during runtime. Make sure that objects that have to be created only once
        are defined either as static class variables or in the __init__ method of this class.
        """
        print('start')
        print(cv2.__version__)
        color = oak.create_camera(source='color', fps=30, encode='h264')
        nn = oak.create_nn('yolov5n_coco_416x416', input=color)
        self.business_logic.live_view = LiveView.create(device=oak, component=color, name="Detection stream", manual_publish=False)
        # define where you want to process data from the camera
        oak.callback(nn.out.main, self.business_logic.process_packets)
